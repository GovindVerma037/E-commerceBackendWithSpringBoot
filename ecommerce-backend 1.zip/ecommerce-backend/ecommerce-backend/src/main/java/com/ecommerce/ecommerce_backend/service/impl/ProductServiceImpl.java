package com.ecommerce.ecommerce_backend.service.impl;

import com.ecommerce.ecommerce_backend.entity.Product;
import com.ecommerce.ecommerce_backend.repository.ProductRepository;
import com.ecommerce.ecommerce_backend.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import java.util.List;
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository repo;

    // Add product
    public Product addProduct(Product product) {
        return repo.save(product);
    }

    // Get all
    public List<Product> getAllProducts() {
        return repo.findAll();
    }

//    public Page<Product> getProducts(int page, int size) {
//        Pageable pageable = PageRequest.of(page, size);
//        return repo.findAll(pageable);
//    }
    // Get by id
    public Product getProductById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    // Update
    public Product updateProduct(Long id, Product updatedProduct) {
        Product existing = getProductById(id);

        existing.setName(updatedProduct.getName());
        existing.setDescription(updatedProduct.getDescription());
        existing.setPrice(updatedProduct.getPrice());
        existing.setImageUrl(updatedProduct.getImageUrl());
        existing.setStock(updatedProduct.getStock());

        return repo.save(existing);
    }

    // Delete
    public void deleteProduct(Long id) {
        repo.deleteById(id);
    }
}