package com.ecommerce.ecommerce_backend.service.impl;

import com.ecommerce.ecommerce_backend.entity.User;
import com.ecommerce.ecommerce_backend.enums.Role;
import com.ecommerce.ecommerce_backend.exception.InvalidPasswordException;
import com.ecommerce.ecommerce_backend.exception.UserNotFoundException;
import com.ecommerce.ecommerce_backend.repository.UserRepository;
import com.ecommerce.ecommerce_backend.security.JwtUtil;
import com.ecommerce.ecommerce_backend.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;



    @Override
    public String register(User user) {

        if (user.getPassword() == null || user.getPassword().isEmpty()) {
            throw new RuntimeException("Password is required");
        }
        System.out.println("Signup password: " + user.getPassword());

        user.setPassword(passwordEncoder.encode(user.getPassword()));

        user.setRole(Role.CUSTOMER);
        userRepository.save(user);

        return "User register Successfully ....";
    }

    @Override
    public String login(String email, String password) {

      User user =  userRepository.findByEmail(email)
              .orElseThrow(()-> new UserNotFoundException("user not found"));

     if(!passwordEncoder.matches(password,user.getPassword())){
         throw  new InvalidPasswordException("invalid password !!!");
     }
        return jwtUtil.generateToken(email);

    }
    @Override
    public User getUser(String email, String password) {

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        return user; // 🔥 ye important hai
    }
}
