package com.ecommerce.ecommerce_backend.service;

import com.ecommerce.ecommerce_backend.entity.Order;
import com.ecommerce.ecommerce_backend.entity.User;

import java.util.List;

public interface OrderService {

        Order palceOrder();
        List<Order> getMyOrders();
        Order getOrderById(Long id);

}
