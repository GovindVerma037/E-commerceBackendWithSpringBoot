package com.ecommerce.ecommerce_backend.controller;

import com.ecommerce.ecommerce_backend.dto.UserResponse;
import com.ecommerce.ecommerce_backend.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ecommerce.ecommerce_backend.entity.Product;
import com.ecommerce.ecommerce_backend.entity.Order;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/users")
    public List<UserResponse> getAllUsers(){
        return adminService.getAllUsers();
    }

    @GetMapping("/user/{id}")
    public UserResponse getUser(@PathVariable Long id) {
        return adminService.getUserById(id);
    }

    @DeleteMapping("/user/{id}")
    public String deleteUser(@PathVariable Long id) {
        adminService.deleteUser(id);
        return "User deleted";
    }

    // Product management

    @PostMapping("/product")
    public Product addProduct(@RequestBody Product product) {
        return adminService.addProduct(product);
    }

    @PutMapping("/product/{id}")
    public Product updateProduct(@PathVariable Long id,
                                 @RequestBody Product product) {
        return adminService.updateProduct(id, product);
    }

    @DeleteMapping("/product/{id}")
    public String deleteProduct(@PathVariable Long id) {
        adminService.deleteProduct(id);
        return "Product deleted";
    }

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return adminService.getAllProducts();
    }

    // orders

    @GetMapping("/orders")
    public List<Order> getAllOrders() {
        return adminService.getAllOrders();
    }

    @GetMapping("/order/{id}")
    public Order getOrder(@PathVariable Long id) {
        return adminService.getOrderById(id);
    }

    @PutMapping("/order/{id}/status/{status}")
    public String updateOrderStatus(
            @PathVariable Long id,
            @PathVariable String status) {

        adminService.updateOrderStatus(id, status);
        return "Order updated";
    }

    // dashboard

    @GetMapping("/dashboard/users")
    public Long totalUsers() {
        return adminService.getTotalUsers();
    }

    @GetMapping("/dashboard/orders")
    public Long totalOrders() {
        return adminService.getTotalOrders();
    }

    @GetMapping("/dashboard/revenue")
    public Double totalRevenue() {
        return adminService.getTotalRevenue();
    }
}
