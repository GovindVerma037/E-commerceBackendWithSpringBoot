package com.ecommerce.ecommerce_backend.controller;

import com.ecommerce.ecommerce_backend.dto.CartItemResponse;
import com.ecommerce.ecommerce_backend.entity.Cart;
import com.ecommerce.ecommerce_backend.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    CartService cartService;

    @PostMapping("/add")
    public Cart add(@RequestParam Long productId , @RequestParam int quantity){

        return cartService.addToCart(productId,quantity);
    }

    @GetMapping
    public List<CartItemResponse> getCart(){
        return cartService.getCart();
    }

    @PutMapping("/update")
    public Cart update(@RequestParam Long productId,@RequestParam int quantity){
        return cartService.updateQuantity(productId,quantity);
    }

    @DeleteMapping("/remove/{productId}")
    public  String remove(@PathVariable Long productId){
      cartService.removeItem(productId);
      return "Item removed !!";
    }

    @DeleteMapping("/clear")
    public String clear(){
        cartService.clearCart();
        return "cart cleared !!!";
    }


}
