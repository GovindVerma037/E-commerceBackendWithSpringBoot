package com.ecommerce.ecommerce_backend.exception;


import com.ecommerce.ecommerce_backend.entity.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {


    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<String> handleUserNotFound(UserNotFoundException ex){

        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);

    }
    @ExceptionHandler(InvalidPasswordException.class)
    public ResponseEntity<String> handlePassword(InvalidPasswordException ex){

        return new ResponseEntity<>(ex.getMessage(),HttpStatus.BAD_REQUEST);

    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGeneral(Exception e){
        e.printStackTrace();
        return new ResponseEntity<>("Something Went Wrong !!!",HttpStatus.INTERNAL_SERVER_ERROR);
    }


}
