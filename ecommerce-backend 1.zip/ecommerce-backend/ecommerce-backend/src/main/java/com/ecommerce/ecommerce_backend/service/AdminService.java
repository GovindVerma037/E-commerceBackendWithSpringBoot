package com.ecommerce.ecommerce_backend.service;

import com.ecommerce.ecommerce_backend.dto.UserResponse;
import com.ecommerce.ecommerce_backend.entity.Order;
import com.ecommerce.ecommerce_backend.entity.Product;
import com.ecommerce.ecommerce_backend.entity.User;
import java.util.List;

public interface AdminService {

    // USER
    List<UserResponse> getAllUsers();
    void deleteUser(Long id);
    UserResponse getUserById(Long id);

    // product
    Product addProduct(Product product);
    Product updateProduct(Long id, Product product);
    void deleteProduct(Long id);
    List<Product> getAllProducts();

    // order
    List<Order> getAllOrders();
    Order getOrderById(Long id);
    void updateOrderStatus(Long orderId, String status);

    // dashboard
    Long getTotalUsers();
    Long getTotalOrders();
    Double getTotalRevenue();
}
