package com.ecommerce.ecommerce_backend.dto;

import lombok.Data;

@Data
public class CartItemResponse {

    private Long productId;
    private String name;
    private Double price;
    private String imageUrl;
    private int quantity;

}
