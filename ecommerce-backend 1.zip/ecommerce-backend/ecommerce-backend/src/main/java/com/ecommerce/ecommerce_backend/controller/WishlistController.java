package com.ecommerce.ecommerce_backend.controller;


import com.ecommerce.ecommerce_backend.entity.Wishlist;
import com.ecommerce.ecommerce_backend.service.WishlistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/wishlist")
public class WishlistController {

    @Autowired
    private WishlistService wishlistService;

    @PostMapping("/add")
    public Wishlist add(@RequestParam Long productId) {
        return wishlistService.addToWishlist(productId);
    }

    @GetMapping
    public Wishlist get() {
        return wishlistService.getWishlist();
    }

    @DeleteMapping("/remove/{productId}")
    public String remove(@PathVariable Long productId) {
        wishlistService.removeFromWishlist(productId);
        return "Removed from wishlist";
    }
}