package com.ecommerce.ecommerce_backend.repository;

import com.ecommerce.ecommerce_backend.entity.WishlistItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WishlistItemRepository extends JpaRepository<WishlistItem, Long> {
}