package com.ecommerce.ecommerce_backend.service.impl;

import com.ecommerce.ecommerce_backend.dto.CartItemResponse;
import com.ecommerce.ecommerce_backend.entity.Cart;
import com.ecommerce.ecommerce_backend.entity.CartItem;
import com.ecommerce.ecommerce_backend.entity.Product;
import com.ecommerce.ecommerce_backend.entity.User;
import com.ecommerce.ecommerce_backend.exception.UserNotFoundException;
import com.ecommerce.ecommerce_backend.repository.CartItemRepository;
import com.ecommerce.ecommerce_backend.repository.CartRepository;
import com.ecommerce.ecommerce_backend.repository.ProductRepository;
import com.ecommerce.ecommerce_backend.repository.UserRepository;
import com.ecommerce.ecommerce_backend.security.JwtUtil;
import com.ecommerce.ecommerce_backend.service.CartService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;


    private User getCurrentUser(){
        String header = request.getHeader("Authorization");


        if(header == null || !header.startsWith("Bearer ")){
            throw new RuntimeException("JWT token missing or invalid");
        }

        String token = header.substring(7);
        String email = jwtUtil.extractEmail(token);

        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    private Cart getOrCreateCart(User user){

        return cartRepository.findByUser(user).orElseGet(()->{
         Cart newCart = new Cart();
         newCart.setUser(user);
         return cartRepository.save(newCart);

        });
    }


    @Override
    public Cart addToCart(Long productId, int quantity) {

        User user =  getCurrentUser();
        Cart cart = getOrCreateCart(user);

        Product product = productRepository.findById(productId)
                         .orElseThrow(()-> new RuntimeException("product not found"));

        CartItem item = cartItemRepository.findByCartAndProduct(cart,product)
                .orElse(null);

        if(item != null){
            item.setQuantity(item.getQuantity()+quantity);
        }else{
            item  =  new CartItem();
            item.setCart(cart);
            item.setProduct(product);
            item.setQuantity(quantity);
        }

        cartItemRepository.save(item);

        return cart;
    }

    @Override
    public List<CartItemResponse> getCart() {

        User user = getCurrentUser();
        Cart cart = getOrCreateCart(user);

        return cart.getItems().stream().map(item -> {
            CartItemResponse res = new CartItemResponse();

            res.setProductId(item.getProduct().getId());
            res.setName(item.getProduct().getName());
            res.setPrice(item.getProduct().getPrice());
            res.setImageUrl(item.getProduct().getImageUrl());
            res.setQuantity(item.getQuantity());

            return res;
        }).toList();
    }

    @Override
    public Cart updateQuantity(Long productId, int quantity) {
        User user = getCurrentUser();
        Cart cart = getOrCreateCart(user);

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        CartItem item = cartItemRepository.findByCartAndProduct(cart, product)
                .orElseThrow(() -> new RuntimeException("Item not in cart"));

        item.setQuantity(quantity);
        cartItemRepository.save(item);
        return cart;
    }

    @Override
    public void removeItem(Long productId) {
        User user = getCurrentUser();
        Cart cart = getOrCreateCart(user);

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        CartItem item = cartItemRepository.findByCartAndProduct(cart, product)
                .orElseThrow(() -> new RuntimeException("Item not found"));

        cartItemRepository.delete(item);
    }

    @Override
    public void clearCart() {
        User user = getCurrentUser();
        Cart cart = getOrCreateCart(user);

        if(cart.getItems() != null){
            cartItemRepository.deleteAll(cart.getItems());
        }
    }
}
