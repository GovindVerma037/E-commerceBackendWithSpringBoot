package com.ecommerce.ecommerce_backend.service;



import com.ecommerce.ecommerce_backend.entity.Wishlist;

public interface WishlistService {

    Wishlist addToWishlist(Long productId);

    Wishlist getWishlist();

    void removeFromWishlist(Long productId);
}