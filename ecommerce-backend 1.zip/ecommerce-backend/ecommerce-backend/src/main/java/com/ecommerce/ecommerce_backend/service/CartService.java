package com.ecommerce.ecommerce_backend.service;

import com.ecommerce.ecommerce_backend.dto.CartItemResponse;
import com.ecommerce.ecommerce_backend.entity.Cart;

import java.util.List;

public interface CartService {

    Cart addToCart(Long productId, int quantity);

    List<CartItemResponse> getCart();

    Cart updateQuantity(Long productId, int quantity);

    void removeItem(Long productId);

    void clearCart();
    
    
}
