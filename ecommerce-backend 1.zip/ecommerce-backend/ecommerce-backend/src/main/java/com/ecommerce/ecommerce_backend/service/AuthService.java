package com.ecommerce.ecommerce_backend.service;

import com.ecommerce.ecommerce_backend.entity.User;

public interface AuthService {

    String register(User user);
    String login(String email,String password);
    User getUser(String email, String password);
}
