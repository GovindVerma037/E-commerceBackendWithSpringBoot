package com.ecommerce.ecommerce_backend.service.impl;


import com.ecommerce.ecommerce_backend.entity.*;
import com.ecommerce.ecommerce_backend.repository.*;
import com.ecommerce.ecommerce_backend.security.JwtUtil;
import com.ecommerce.ecommerce_backend.service.WishlistService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class WishlistServiceImpl implements WishlistService {

    @Autowired
    private WishlistRepository wishlistRepository;

    @Autowired
    private WishlistItemRepository wishlistItemRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private HttpServletRequest request;

    private User getCurrentUser() {
        String header = request.getHeader("Authorization");
        String token = header.substring(7);

        String email = jwtUtil.extractEmail(token);

        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    private Wishlist getOrCreateWishlist(User user) {
        return wishlistRepository.findByUser(user)
                .orElseGet(() -> {
                    Wishlist w = new Wishlist();
                    w.setUser(user);
                    return wishlistRepository.save(w);
                });
    }

    @Override
    public Wishlist addToWishlist(Long productId) {

        User user = getCurrentUser();
        Wishlist wishlist = getOrCreateWishlist(user);

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // check duplicate
        boolean exists = wishlist.getItems().stream()
                .anyMatch(item -> item.getProduct().getId().equals(productId));

        if (!exists) {
            WishlistItem item = new WishlistItem();
            item.setWishlist(wishlist);
            item.setProduct(product);

            wishlist.getItems().add(item);
            wishlistItemRepository.save(item);
        }

        return wishlistRepository.save(wishlist);
    }

    @Override
    public Wishlist getWishlist() {
        User user = getCurrentUser();
        return getOrCreateWishlist(user);
    }

    @Override
    public void removeFromWishlist(Long productId) {

        User user = getCurrentUser();
        Wishlist wishlist = getOrCreateWishlist(user);

        wishlist.getItems().removeIf(item ->
                item.getProduct().getId().equals(productId)
        );

        wishlistRepository.save(wishlist);
    }
}
