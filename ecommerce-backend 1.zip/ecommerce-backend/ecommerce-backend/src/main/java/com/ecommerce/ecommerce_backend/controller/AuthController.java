package com.ecommerce.ecommerce_backend.controller;

import com.ecommerce.ecommerce_backend.dto.AuthRequest;
import com.ecommerce.ecommerce_backend.dto.AuthResponse;
import com.ecommerce.ecommerce_backend.entity.User;
import com.ecommerce.ecommerce_backend.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/signup")
    public ResponseEntity<String> register(@RequestBody User user){
      return ResponseEntity.ok(authService.register(user));
    }
    @PostMapping("/signing")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest req){

        User user = authService.getUser(req.getEmail(), req.getPassword());
         String token = authService.login(req.getEmail(), req.getPassword());

      return  ResponseEntity.ok(new AuthResponse(token, "Login successful",String.valueOf(user.getRole())));
    }
}
